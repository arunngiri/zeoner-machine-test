<?php $__env->startComponent('mail::message'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Employee Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            width: 80%;
            margin: 0 auto;
        }
        .details-table {
            width: 100%;
            border-collapse: collapse;
        }
        .details-table th,
        .details-table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        .details-table th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Employee Details</h2>
        <table class="details-table">
            <thead>
            </thead>
            <tbody>
                <?php $__currentLoopData = $employeeDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th>Emp No:</th>
                    <th><?php echo e($loop->iteration); ?></th>
                </tr>
                <tr>
                    <td>First name:</td>
                    <td><?php echo e($employee->first_name); ?></td>
                </tr>
                <tr>
                    <td>Last name:</td>
                    <td><?php echo e($employee->last_name); ?></td>
                </tr>
                <tr>
                    <td>Age:</td>
                    <td><?php echo e($employee->age); ?></td>
                </tr>
                <tr>
                    <td>Gender:</td>
                    <td><?php echo e($employee->gender); ?></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><?php echo e($employee->email); ?></td>
                </tr>
                <tr>
                    <td>Address:</td>
                    <td><?php echo e($employee->address); ?></td>
                </tr>
                <tr>
                    <td>College name:</td>
                    <td><?php echo e($employee->college_name); ?></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><?php echo e($employee->school_name); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        Thanks, Zeoner
    </div>
</body>
</html>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\arunk\Downloads\task-one - Copy\task-one\resources\views/emails/new_email_address.blade.php ENDPATH**/ ?>