<?php echo e($slot); ?>

<?php /**PATH C:\Users\arunk\Downloads\task-one - Copy\task-one\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>