<div class="">
    <table class="table">
        <thead>
            <tr>
                <th>(## First Name ##)</th>
                <th>(## Last Name ##)</th>
                <th>(## Age ##)</th>
                <th>(## Gender ##)</th>
                <th>(## Email ##)</th>
                <th>(## Address ##)</th>
                <th>(## College Name ##)</th>
                <th>(## School Name ##)</th>
            </tr>
        </thead>
        <tbody> 
            <tr>
                <td><?php echo e($employee_list->first_name); ?></td>
                <td><?php echo e($employee_list->last_name); ?></td>
                <td><?php echo e($employee_list->age); ?></td>
                <td><?php echo e($employee_list->gender); ?></td>
                <td><?php echo e($employee_list->email); ?></td>
                <td><?php echo e($employee_list->address); ?></td>
                <td><?php echo e($employee_list->college_name); ?></td>
                <td><?php echo e($employee_list->school_name); ?></td>
            </tr>
            
        </tbody>
    </table>
</div><?php /**PATH C:\Users\arunk\Downloads\task-one - Copy\task-one\resources\views/templates/employee_list.blade.php ENDPATH**/ ?>