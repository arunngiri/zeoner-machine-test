

<style>
    h4{
        color: #fff;
        padding: 0px !important;
        margin: 0px !important;
    }

    /* Chrome, Safari, Edge, Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
    }

    /* Firefox */
    input[type=number] {
    -moz-appearance: textfield;
    }
</style>
<?php $__env->startSection('content'); ?>
    <div class="bg-light p-5 rounded">
        <?php if(auth()->guard()->check()): ?>
            <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <section>
                <div class="card mb-4" style="background-color: #1f275d;" >
                    <?php if((request()->edit_id)): ?>
                        <div class="card-body" style="text-align: center;">
                            <h4>Edit Employee Form </h4>
                        </div>
                    <?php else: ?>
                        <div class="card-body" style="text-align: center;">
                            <h4>Add Employee Form </h4>
                        </div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('store-employee')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="container">
                        <div class="row g-3">
                            <div class="col">
                                <?php if(isset(request()->edit_id)): ?>
                                    <input type="hidden" name="edit" value="<?php echo e(request()->edit_id); ?>">
                                <?php endif; ?>
                                <label for="" class="mb-2">First name <span class='text-danger'>*</span></label>
                                <input type="text" class="form-control" value="<?php echo e($edit_details->first_name ?? ''); ?>" name="first_name" placeholder="Enter First name" aria-label="First name" required>
                            </div>
                            <div class="col">
                                <label for="" class="mb-2">Last name <span class='text-danger'>*</span></label>
                                <input type="text" class="form-control" value="<?php echo e($edit_details->last_name ?? ''); ?>" name="last_name" placeholder="Enter Last name" aria-label="Last name" required>
                            </div>
                        </div>
                        <div class="row g-3 mt-3">
                            <div class="col">
                                <label for="" class="mb-2">Age <span class='text-danger'>*</span></label>
                                <input type="number" class="form-control" value="<?php echo e($edit_details->age ?? ''); ?>" name="age" placeholder="Enter Age" aria-label="Age" required>
                            </div>
                            <div class="col">
                                <label for="" class="mb-2">Gender <span class='text-danger'>*</span></label>
                                <select class="form-select" name="gender" required>
                                    <option value="" disabled>Select Gender</option>
                                    <option value="Men" <?php echo e(isset($edit_details->gender) && $edit_details->gender == 'Men' ? "selected" : ''); ?>>Men</option>
                                    <option value="Woman" <?php echo e(isset($edit_details->gender) && $edit_details->gender == 'Woman' ? "selected" : ''); ?>>Woman</option>
                                    <option value="Others" <?php echo e(isset($edit_details->gender) && $edit_details->gender == 'Others' ? "selected" : ''); ?>>Others</option>
                                  </select>
                            </div>
                        </div>
                        <div class="row g-3 mt-3">
                            <div class="col">
                                <label for="" class="mb-2">Email <span class='text-danger'>*</span></label>
                                <input type="email" class="form-control" value="<?php echo e($edit_details->email ?? ''); ?>" name="email" placeholder="Enter Email" aria-label="email" required>
                            </div>
                            <div class="col">
                                <label for="" class="mb-2">Address <span class='text-danger'>*</span></label>
                                <input type="text" class="form-control" value="<?php echo e($edit_details->address ?? ''); ?>" name="address" placeholder="Enter Address" aria-label="Address" required>
                             </div>
                        </div>
                        <div class="row g-3 mt-3">
                            <div class="col">
                                <label for="" class="mb-2">College name </label>
                                <input type="text" class="form-control" value="<?php echo e($edit_details->college_name ?? ''); ?>" name="college_name" placeholder="Enter College name" aria-label="College name">
                            </div>
                            <div class="col">
                                <label for="" class="mb-2">School name </label>
                                <input type="text" class="form-control" value="<?php echo e($edit_details->school_name ?? ''); ?>" name="school_name" placeholder="Enter School name" aria-label="School name">
                             </div>
                        </div>
                        <?php if(request()->edit_id): ?>
                            <div class="mt-5" style="text-align: center;">
                                <button type="submit" class="btn btn-success"> <i class="fa fa-save"></i> Update</button>
                            </div>
                        <?php else: ?>
                            <div class="mt-5" style="text-align: center;">
                                <button type="submit" class="btn btn-success"> <i class="fa fa-save"></i> Success</button>
                            </div>
                        <?php endif; ?>
                    </div>
                </form>
            </section>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arunk\Downloads\task-one - Copy\task-one\resources\views/home/add_employee.blade.php ENDPATH**/ ?>