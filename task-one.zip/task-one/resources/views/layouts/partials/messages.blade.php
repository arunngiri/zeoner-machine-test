@if(isset ($errors) && count($errors) > 0)
    <div class="alert alert-danger" role="alert">
        <ul class="list-unstyled mb-0">
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            @endforeach
        </ul>
    </div>
@endif

@if(Session::get('success', false))
    <?php $data = Session::get('success'); ?>
    @if (is_array($data))
        @foreach ($data as $msg)
            <div class="alert alert-success" role="alert">
                <div class="row">
                    <div class="col-md-6">
                        <i class="fa fa-check"></i>
                        {{ $msg }}
                    </div>
                    <div class="col-md-6">
                        <div style="text-align: right">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    @else
        <div class="alert alert-success" role="alert">
            <div class="row">
                <div class="col-md-6">
                    <i class="fa fa-check"></i>
                    {{ $data }}
                </div>
                <div class="col-md-6">
                    <div style="text-align: right">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </div>
    @endif
@endif