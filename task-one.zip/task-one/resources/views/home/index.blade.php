@extends('layouts.app-master')
@section('content')
    <style>
        .alert{
            padding: 10px 10px !important;
            margin: 0px !important;
        }
        h4{
            color: #fff;
            padding: 0px !important;
            margin: 0px !important;
        }
        .btn-warning{
            color: #fff !important;
        }
    </style>

    <div class="bg-light p-5 rounded">
        @auth
            <section>
                <div class="">
                    <div class="">
                        @include('layouts.partials.messages')
                    </div>
                </div>
            </section>
            <section class="mt-1">
                <div class="card mb-4" style="background-color: #1f275d;" >
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Employee lists</h4>
                            </div>
                            <div class="col-md-6" style="text-align: right;">
                                <button type="button" class="btn btn-warning mail_popup" data-toggle="modal" data-target="#myModal">
                                    SendMail <i class="fa fa-envelope"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <table class="table" id="dataTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- The Modal -->
                <div class="modal" id="myModal">
                    <div class="modal-dialog">
                    <div class="modal-content">
                        <!-- Modal Header -->
                        <div class="modal-header">
                        <h4 class="modal-title">Send Mail</h4>
                            <button type="button" class="close btn btn-secondary" data-dismiss="modal">&times;</button>
                        </div>
                
                        <!-- Modal body -->
                        <div class="modal-body">
                            <form id="emailForm">
                                <label for="email" class="mb-2">Email Address: <span class='text-danger'>*</span></label>
                                <input type="email" class="form-control mb-2" id="email" name="email">
                                <label for="email" class="mb-2">Say Somthing <span class='text-danger'>*</span></label>
                                <textarea name="content" class="form-control mb-2" id="content" cols="3" rows="3"></textarea>
                                <a id="send_mail" class="btn btn-success">Send Mail <i class="fa fa-send-o"></i></a>
                            </form>
                        </div>
                
                        <!-- Modal footer -->
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                    </div>
                </div>
            </section>
        @endauth

        @guest
        <h1>Home</h1>
        <p class="lead">Your viewing the employee details. Please login to view the restricted data.</p>
        @endguest
    </div>
@endsection
@section('inline')
    <script>
         $(document).ready(function() {
            $('#dataTable').DataTable({
                processing: true,
                serverSide: true,
                responsive: true,
                ajax: {
                    url: "{{ route('get-employee') }}",
                    type: 'GET',
                    data: {
                        employee_table: true,
                        "_token": "{{ csrf_token() }}",
                    },
                    dataType: 'json',
                },
                columns: [
                    { data: 'id', name: 'id' },
                    { data: 'first_name', name: 'first_name' },
                    { data: 'last_name', name: 'last_name' },
                    { data: 'email', name: 'email' },
                    {data: 'action', name: 'action', orderable: false, searchable: false, className: 'text-center'},
                ]
            });
        });

        //Edit
        $(document).on('click', '.deleteRow', function(e){
            var delete_id = $(this).attr('data-id');
            var result = confirm("Want to delete?");
            if (result) {
                $.ajax({
                    url:"{{ route('delete-employee') }}",
                    data: {"_token": "{{ csrf_token() }}","delete_id": delete_id,"employee_delete":'true'},
                    dataType: 'json',
                    type: 'POST',
                    success: function(data) {
                        if(data.response == true){
                            location.reload();
                        }
                    }
                });
            }
        });

        //
        $(document).ready(function () {
            $(".mail_popup").click(function () {
            $("#myModal").modal("show");
        });

        //Send Mail
        $(document).on('click', '#send_mail', function(e){
            const email = $("#email").val();
            const content = $("#content").val();
            if(email != '' && content !=''){
                loader('open');
                $.ajax({
                    url: "{{ route('send-mail') }}",
                    type: 'POST',
                    data: {
                        send_mail_status : true,
                        "_token" : "{{ csrf_token() }}",
                        email : email,
                        content : content,
                    },
                    success: function (response) {
                        loader('close');
                        $('#myModal').modal('hide');
                        alert(response.message);
                    },
                    error: function (error) {
                        console.error(error);
                    },
                });
            }else{
                alert('Required field is empty!')
            }
        });

        //
        function loader(state){
            var options = {
                theme:"sk-cube-grid",
                backgroundColor:"#e2e2e2",
                textColor:"white"
            };
            if(state == 'open'){
                HoldOn.open(options);
            } else if(state == 'close'){
                HoldOn.close();
            }
        }
    });
    </script>
@endsection