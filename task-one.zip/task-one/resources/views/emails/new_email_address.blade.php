@component('mail::message')
<!DOCTYPE html>
<html>
<head>
    <title>Employee Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            width: 80%;
            margin: 0 auto;
        }
        .details-table {
            width: 100%;
            border-collapse: collapse;
        }
        .details-table th,
        .details-table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        .details-table th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Employee Details</h2>
        <table class="details-table">
            <thead>
            </thead>
            <tbody>
                @foreach ($employeeDetails as $employee)
                <tr>
                    <th>Emp No:</th>
                    <th>{{ $loop->iteration }}</th>
                </tr>
                <tr>
                    <td>First name:</td>
                    <td>{{ $employee->first_name }}</td>
                </tr>
                <tr>
                    <td>Last name:</td>
                    <td>{{ $employee->last_name }}</td>
                </tr>
                <tr>
                    <td>Age:</td>
                    <td>{{ $employee->age }}</td>
                </tr>
                <tr>
                    <td>Gender:</td>
                    <td>{{ $employee->gender }}</td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td>{{ $employee->email }}</td>
                </tr>
                <tr>
                    <td>Address:</td>
                    <td>{{ $employee->address }}</td>
                </tr>
                <tr>
                    <td>College name:</td>
                    <td>{{ $employee->college_name }}</td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td>{{ $employee->school_name }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
        Thanks, Zeoner
    </div>
</body>
</html>
@endcomponent
