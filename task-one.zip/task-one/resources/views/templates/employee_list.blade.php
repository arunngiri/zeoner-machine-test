<div class="">
    <table class="table">
        <thead>
            <tr>
                <th>(## First Name ##)</th>
                <th>(## Last Name ##)</th>
                <th>(## Age ##)</th>
                <th>(## Gender ##)</th>
                <th>(## Email ##)</th>
                <th>(## Address ##)</th>
                <th>(## College Name ##)</th>
                <th>(## School Name ##)</th>
            </tr>
        </thead>
        <tbody> 
            <tr>
                <td>{{ $employee_list->first_name }}</td>
                <td>{{ $employee_list->last_name }}</td>
                <td>{{ $employee_list->age }}</td>
                <td>{{ $employee_list->gender }}</td>
                <td>{{ $employee_list->email }}</td>
                <td>{{ $employee_list->address }}</td>
                <td>{{ $employee_list->college_name }}</td>
                <td>{{ $employee_list->school_name }}</td>
            </tr>
            {{-- @foreach ($employee_list as $employee)
            @endforeach --}}
        </tbody>
    </table>
</div>