<?php

namespace App\Exports;

use App\Models\EmployeeModel;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use Illuminate\Http\Request as HttpRequest;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithTitle;

class EmployeeExport implements FromView, ShouldAutoSize, WithTitle
{
    use Exportable;
    /**
    * @return \Illuminate\Support\Collection
    */

    protected $request;
    public function __construct(HttpRequest $request)
    {
        $this->request = $request;
    }

    public function view(): View
    {   
        
        $employee_list = EmployeeModel::where('id',$this->request->down_id)->first();
        
        return view('templates.employee_list', [
            'employee_list' => $employee_list
        ]);
    }

    public function title(): string
    {
        return 'Employee Details';
    }
}
