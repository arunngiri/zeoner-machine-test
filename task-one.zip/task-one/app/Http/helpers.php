<?php

use Illuminate\Http\Client\Response;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Storage;



function dtEdit($data)
{
    $conf = ' ';
    $custom_class = '';
    $link = '';

    if(isset($data['id'])){
        $conf .= 'data-id="'.$data['id'].'"';
    }
    if(isset($data['class'])){
        $custom_class = ' '.$data['class'];
    }

    if(isset($data['data_value'])){
        foreach ($data['data_value'] as $key => $dval) {
            $conf .= 'data-'. $key.'="'.$dval.'"';
        }
    }
    if(isset($data['link'])){
        $link = ' '.$data['link'];
    }
    return '<a href="'.$link.'" class="editRow btn btn-primary btn-tb-actions mr-1 me-2'.$custom_class.'" '.$conf. ' data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"><i class="fa fa-pencil"></i></a>';
}

function dtDelete($data)
{
    $conf = ' ';
    $custom_class = '';

    if (isset($data['id'])) {
        $conf .= 'data-id="' . $data['id'] . '"';
    }
    if (isset($data['class'])) {
        $custom_class = ' ' . $data['class'];
    }

    if (isset($data['data_value'])) {
        foreach ($data['data_value'] as $key => $dval) {
            $conf .= 'data-' . $key . '="' . $dval . '"';
        }
    }
    return '<button type="button" class="deleteRow btn btn-danger btn-tb-actions mr-1 me-2' . $custom_class . '" ' . $conf . ' data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"><i class="fa fa-trash-o"></i></button>';
}

function dtDownload($data)
{
    $conf = ' ';
    $custom_class = '';
    $link = '';
    if(isset($data['id'])){
        $conf .= 'data-id="'.$data['id'].'"';
    }
    if(isset($data['class'])){
        $custom_class = ' '.$data['class'];
    }
    if(isset($data['link'])){
        $link = ' '.$data['link'];
    }
    return '<a href="'.$link.'" class=" btn btn-success waves-effect waves-light mr-1'.$custom_class.'" '.$conf. ' data-bs-toggle="tooltip" data-bs-placement="top" title="Download"><i class="fa fa-download"></i></a>';
}