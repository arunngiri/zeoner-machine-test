<?php
//echo '<pre>';
//echo print_r();
//echo '</pre>';
//exit;
namespace App\Http\Controllers;

use App\Exports\EmployeeExport;
use App\Mail\EmployeeEmailAddress;
use App\Models\EmployeeModel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;
use Yajra\DataTables\Facades\DataTables;

class HomeController extends Controller
{
    public function index() 
    {
        return view('home.index');
    }

    //Add Employess
    public function addEmployee (Request $request){

        if(request()->get('edit_id')){
            $data = [];
            $data['edit_details'] = EmployeeModel::where('id', $request->edit_id)->first();
            $data['status'] = true;
        }else{
            $data = '';
        }

        return view('home.add_employee')->with($data);
    }

    //Employee Details Store
    public function storeEmployee (Request $request){

        if(request()->method() == 'POST' || request()->get('edit')){
            try{
                $validated = $request->validate([
                    'first_name' => 'required',
                    'last_name' => 'required',
                    'age' => 'required',
                    'gender' => 'required',
                    'email' => 'required',
                    'address' => 'required',
                ]);

                if($validated){
                    $insert = [
                        'first_name' => $request->first_name,
                        'last_name' => $request->last_name,
                        'age' => $request->age,
                        'gender' => $request->gender,
                        'email' => $request->email,
                        'address' => $request->address,
                        'college_name' => $request->college_name,
                        'school_name' => $request->school_name,
                        'created_at' => Carbon::now(),
                    ];
                    $count = EmployeeModel::where('id', $request->edit)->count();
                    if($count > 0){
                        EmployeeModel::where('id', $request->edit)->update($insert);
                        session()->flash('success', 'Employee Details Updated Successfully');
                        return redirect()->route('index');
                    }else{
                        EmployeeModel::insert($insert);
                    }
                }
                session()->flash('success', 'Employee Details Added Successfully');
                return redirect()->route('index');
            } catch (\Exception $e) {
                Log::channel('errorspot')->Error($e->getMessage());
                return redirect()->back()->with('error', 'Employee Details Not Added, Please Try Again After Sometime!');
            }
        }
    }

    //Get Employee Details
    public function getEmployee (Request $request){
        if(request()->get('employee_table')){
            $data = EmployeeModel::all();
            return DataTables::of($data)
            ->addIndexColumn()
            ->addColumn('action', function ($row) {
                $path = route('add-employee').'?edit_id='.$row->id;
                $download = route('download-employee').'?down_id='.$row->id;
                $btn = dtEdit(['id' => $row->id, 'link'=> $path]);
                $btn .= dtDelete(['id' => $row->id]);
                $btn .= dtDownload(['id' => $row->id, 'link' => $download]);
                return $btn;
            })
            ->rawColumns(['action'])
            ->make(true);

        }
    }

    //Delete Employee Details
    public function deleteEmployee (Request $request){
        try{
            EmployeeModel::where('id', $request->delete_id)->delete();
            session()->flash('success', 'Employee Details Deleted Successfully');
            return response()->json(['response' => true]);
        }catch (\Exception $e) {
            Log::channel('errorspot')->Error($e->getMessage());
            session()->flash('error', 'Employee Details Not Deleted, Please Try Again After Sometime!');
            return response()->json(['response' => false]);
        }
    }

    //Download Employee Details
    public function downloadEmployee (Request $request){
        return Excel::download(new EmployeeExport($request), 'Employee_Details.xlsx');
    }

    //Send Mail
    public function sendMail (Request $request){
        if(request()->get('send_mail_status') == true){
            $email = $request->input('email');
            $subject = "Employee Details";
            $content = $request->input('content');
            $employeeDetails = EmployeeModel::all();
            Mail::to($email)->send(new EmployeeEmailAddress($employeeDetails, $content, $subject));
            return response()->json(['message' => 'Email sent successfully!']);
        }
    }
}
