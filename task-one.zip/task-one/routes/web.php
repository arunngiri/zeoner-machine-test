<?php

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/clear-cache-all', function () {
    Artisan::call('cache:clear');
    Artisan::call('config:clear');
    Artisan::call('config:cache');
    Artisan::call('view:clear');
    Artisan::call('route:clear');
    Artisan::call('queue:restart');
    return "Cleared!";
});
Route::group(['namespace' => 'App\Http\Controllers'], function()
{   
    /**
     * Home Routes
     */
    //Route::get('/', 'HomeController@index')->name('home.index');
    Route::any('/', [HomeController::class, 'index'])->name('index');


    Route::group(['middleware' => ['guest']], function() {
        /**
         * Register Routes
         */
        Route::get('/register', 'RegisterController@show')->name('register.show');
        Route::post('/register', 'RegisterController@register')->name('register.perform');

        /**
         * Login Routes
         */
        Route::get('/login', 'LoginController@show')->name('login.show');
        Route::post('/login', 'LoginController@login')->name('login.perform');

    });

    Route::group(['middleware' => ['auth']], function() {
        /**
         * Logout Routes
         */
        Route::get('/logout', 'LogoutController@perform')->name('logout.perform');
        Route::any('add-employe', [HomeController::class, 'addEmployee'])->name('add-employee');
        Route::any('store-employe', [HomeController::class, 'storeEmployee'])->name('store-employee');
        Route::any('get-employe', [HomeController::class, 'getEmployee'])->name('get-employee');
        Route::any('delete-employe', [HomeController::class, 'deleteEmployee'])->name('delete-employee');
        Route::any('download-employe', [HomeController::class, 'downloadEmployee'])->name('download-employee');
        Route::any('send-mail', [HomeController::class, 'sendMail'])->name('send-mail');
    });
});
